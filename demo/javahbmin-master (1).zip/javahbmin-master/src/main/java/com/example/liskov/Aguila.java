package com.example.liskov;

public class Aguila extends AveVoladora {

    public Aguila(int peso, int velocidad) {
        super(peso, velocidad);       
    }
    
}
