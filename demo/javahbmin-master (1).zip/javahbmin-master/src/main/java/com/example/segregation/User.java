package com.example.segregation;

public class User {
    
}
