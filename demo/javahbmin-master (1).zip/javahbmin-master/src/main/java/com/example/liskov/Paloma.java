package com.example.liskov;

public class Paloma extends AveVoladora {

    public Paloma(int peso, int velocidad) {
        super(peso, velocidad);        
    }
    
}
