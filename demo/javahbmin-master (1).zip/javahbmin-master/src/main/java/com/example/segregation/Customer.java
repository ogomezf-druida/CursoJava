package com.example.segregation;

public class Customer {
    
}
