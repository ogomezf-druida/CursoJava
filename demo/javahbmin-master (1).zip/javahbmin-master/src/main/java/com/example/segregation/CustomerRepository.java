package com.example.segregation;

public class CustomerRepository implements Repository<Customer,Integer> {

    @Override
    public void add(Customer entity) {
        
    }

    @Override
    public void update(Customer entity) {
        
    }

    @Override
    public Customer get(Integer id) {
        
        return null;
    }

    @Override
    public void remove(Customer entity) {
        
        
    }

   
    
}
