package com.example.liskov;

public class Pinguino extends AveNoVoladora {

    public Pinguino(int peso) {
        super(peso);       
    }
    
}
