package com.example.segregation;

public interface Get<T,ID> {
    T get(ID id);
}
