package com.example;

/*import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;*/

//@Entity
//@Table(name="Events")
public class Events {      
        //@Id 
        public int id;        
}
