package com.example.liskov;

public abstract class AveNoVoladora extends Ave {

    public AveNoVoladora(int peso) {
        super(peso);
        
    }
    
}
