package com.example.segregation;

public interface Add<T> {
    void add(T entity);
}
